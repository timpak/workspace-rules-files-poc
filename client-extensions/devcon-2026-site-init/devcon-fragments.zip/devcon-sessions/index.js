(function() {
	var grid = document.getElementById('devcon-sessions-grid-${fragmentEntryLinkNamespace}');
	var scopeId = Liferay.ThemeDisplay.getScopeGroupId();

	Liferay.Util.fetch('/o/c/sessions/scopes/' + scopeId + '?nestedFields=sessionSpeakers&pageSize=100')
		.then(function(r) { return r.json(); })
		.then(function(data) {
			var sessions = data.items || [];
			if (!sessions.length) {
				grid.innerHTML = '<p>No sessions found.</p>';
				return;
			}
			grid.innerHTML = sessions.map(function(session) {
				var speakers = (session.sessionSpeakers || []).map(function(s) { return s.name; }).join(', ');
				return '<div class="devcon-session-card">' +
					'<h3 class="devcon-session-card-title">' + session.title + '</h3>' +
					'<div class="devcon-session-card-meta">' +
					'<span class="devcon-session-card-time">' + session.startTime + '</span>' +
					'<span class="devcon-session-card-room">' + session.room + '</span>' +
					'<span class="devcon-session-card-speaker">' + (speakers || 'TBA') + '</span>' +
					'</div>' +
					'</div>';
			}).join('');
		})
		.catch(function() {
			grid.innerHTML = '<p>Could not load sessions.</p>';
		});
})();
