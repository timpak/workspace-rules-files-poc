(function() {
	var grid = document.getElementById('devcon-speakers-grid-${fragmentEntryLinkNamespace}');
	var scopeId = Liferay.ThemeDisplay.getScopeGroupId();

	Liferay.Util.fetch('/o/c/speakers/scopes/' + scopeId + '?pageSize=100')
		.then(function(r) { return r.json(); })
		.then(function(data) {
			var speakers = data.items || [];
			if (!speakers.length) {
				grid.innerHTML = '<p>No speakers found.</p>';
				return;
			}
			grid.innerHTML = speakers.map(function(speaker) {
				var initials = speaker.name.split(' ').map(function(w) { return w.charAt(0); }).join('').substring(0, 2).toUpperCase();
				var avatarHtml = speaker.photo
					? '<img src="' + speaker.photo + '" alt="' + speaker.name + '" class="devcon-speaker-photo" />'
					: '<div class="devcon-speaker-avatar">' + initials + '</div>';
				return '<div class="devcon-speaker-card">' +
					avatarHtml +
					'<h3 class="devcon-speaker-name">' + speaker.name + '</h3>' +
					'<p class="devcon-speaker-title">' + (speaker.jobTitle || '') + '</p>' +
					'<p class="devcon-speaker-bio">' + (speaker.bio || '') + '</p>' +
					'</div>';
			}).join('');
		})
		.catch(function() {
			grid.innerHTML = '<p>Could not load speakers.</p>';
		});
})();
